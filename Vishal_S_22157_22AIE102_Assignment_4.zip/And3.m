function [out_and3]= And3(a,b,c)
if a==1 && b==1 & c==1
    out_and3=1;
   
else out_and3=0;
end
end
